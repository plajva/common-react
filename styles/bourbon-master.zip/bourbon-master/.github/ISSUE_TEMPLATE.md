<!-- Feel free to remove any part of this issue template that is not relevant -->
<!-- Providing context helps us come up with a useful solution -->

## Description

<!-- What did you expect to happen? What happened instead? Was a specific error thrown? -->

## Steps to Reproduce

<!-- If you can reproduce the bug in a CodePen, link to it here -->

1. Step 1…
2.
3.

## Development Environment

<!--- Include as many relevant details about the environment you experienced the bug in -->

- Bourbon version:
- Platform:
- Link to the code repository:
