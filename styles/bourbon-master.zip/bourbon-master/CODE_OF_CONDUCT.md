# Code of Conduct

By participating in this project, you agree to abide by the
[thoughtbot code of conduct][tb-coc].

[tb-coc]: https://thoughtbot.com/open-source-code-of-conduct
