module Bourbon
  VERSION = "7.0.0"
end
